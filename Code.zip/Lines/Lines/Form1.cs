﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Lines
{
    public partial class Form1 : Form
    {
        float ox = 12;
        float oy = 555;
        float _beta = 0F;
        int multiplier = 20;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics gi = CreateGraphics();

            /* Assi cartesiani */
            DrawOrtoAxis('x', gi);
            DrawOrtoAxis('y', gi);

            /* Assi non ortogonali */
            DrawPrimedAxis(_beta, 'x', gi);
            DrawPrimedAxis(_beta, 'y', gi);

            /* Disegna squadraturaa */
            DrawLine(new Punto(0, 0), new Punto(100, 100), gi, new Pen(Color.Blue, 1));
            if(checkBox2.Checked)
                DrawPrimed(new Pen(Color.Blue, 1));
            if(checkBox1.Checked)
                DrawNormal(new Pen(Color.Black, 0.5F));


            void DrawLine(Punto A, Punto B, Graphics g, Pen pen)
            {
                float Ax = ox + multiplier * A.x;
                float Ay = oy - multiplier * A.y;
                float Bx = ox + multiplier * B.x;
                float By = oy - multiplier * B.y;
                g.DrawLine(pen, Ax, Ay, Bx, By);
            }

            void DrawPrimedAxis(float beta, char axis, Graphics g)
            {
                Pen pen = new Pen(Color.Red, 1);
                float x = ox, y = oy;
                float lenght = 1000;

                if (axis == 'x')
                {
                    x = x + lenght;
                    y = y - beta * lenght;
                }
                if (axis == 'y')
                {
                    x = x + beta * lenght;
                    y = y - lenght;
                }


                g.DrawLine(pen, ox, oy, x, y);
                pen.Dispose();
            }

            void DrawOrtoAxis(char axis, Graphics g)
            {
                Pen pen = new Pen(Color.Black, 1);
                float x = ox, y = oy;
                float lenght = 1000;

                if (axis == 'x')
                {
                    x = x + lenght;
                }
                if (axis == 'y')
                {
                    y = y - lenght;
                }


                g.DrawLine(pen, ox, oy, x, y);
                pen.Dispose();
            }

            void DrawPoint(Punto punto, Graphics g)
            {
                Pen pen = new Pen(Color.Blue, 2);
                float x = ox + multiplier * punto.x;
                float y = oy - multiplier * punto.y;
                g.DrawLine(pen, x - 1, y + 1, x + 1, y - 1);
            }

            void DrawPrimed(Pen pen)
            {
                for (int i = 0; i < 20; i++) {
                    Punto p1 = new Punto((float)(i / Math.Sqrt(1 - _beta * _beta)), (float)(i * _beta / Math.Sqrt(1 - _beta * _beta)));
                    Punto p2 = new Punto((float)(i * _beta / Math.Sqrt(1 - _beta * _beta)), (float)(i / Math.Sqrt(1 - _beta * _beta)));
                    Punto q = new Punto((float)((i + i * _beta) / Math.Sqrt(1 - _beta * _beta)), (float)((i + i * _beta) / Math.Sqrt(1 - _beta * _beta)));
                    DrawLine(p1, new Punto(q.x + multiplier * (q.x - p1.x), q.y + multiplier * (q.y - p1.y)), gi, pen);
                    DrawLine(p2, new Punto(q.x + multiplier * (q.x - p2.x), q.y + multiplier * (q.y - p2.y)), gi, pen);
                    //DrawLine(p2, q, gi, pen);
                }
            }

            void DrawNormal(Pen pen)
            {
                for (int i = 0; i < 20; i++)
                {
                    Punto p1 = new Punto(i, 0);
                    Punto p2 = new Punto(0, i);
                    Punto q = new Punto(i, i);
                    DrawLine(p1, new Punto(q.x, q.y + 20), gi, pen);
                    DrawLine(p2, new Punto(q.x + 20, q.y), gi, pen);
                }
            }
        }

        private void trackBar1_ValueChanged(object sender, EventArgs e)
        {
            double beta = (double)trackBar1.Value / 10;
            _beta = (float)beta;
            label1.Text = "β = " + _beta + "\nv = " + _beta + " c";

            //FONDAMENTALE!!!//
            this.Invalidate();
        }

        private void checkBox1_Click(object sender, EventArgs e)
        {
            //FONDAMENTALE!!!//
            this.Invalidate();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            //FONDAMENTALE!!!//
            this.Invalidate();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            multiplier = (int)numericUpDown1.Value;

            //FONDAMENTALE!!!//
            this.Invalidate();
        }
    }

    public class Punto
    {
        public float x;
        public float y;

        public Punto(float x, float y)
        {
            this.x = x;
            this.y = y;
        }
    }
}
